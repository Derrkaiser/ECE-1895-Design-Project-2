# ECE-1895-Design-Project-2
Git Repository for ECE 1895 Design Project #2: Bop-it

Project: **Whack-a-mole**

## Team Roles:
Liam Salter    : PCB Design, Soldering Lead, Hardware Integration\
Matthew Kaiser : Software Design, Software Integration\
Tori Csanadi   : Enclosure Design, Preliminary Electronics Testing

### Project Organization:
**Software** is located in Software Design Files\
	- Main contains the game program\
	- Other folders are testing code for their labeled component

**PCB files** are located in Hardware Design Files

**Enclosure files** are located in Enclosure Design Files\
	- Individual components are in their seperate subfolders

**Audio** files that were stored on the SD card located in Audio Files
	
### Drive Folder:
https://drive.google.com/drive/folders/1-efV6e-7OoFiT8zlSRkoNkXt6zLdJ2vi
